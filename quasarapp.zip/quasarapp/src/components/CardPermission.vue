<template>
  <div class="q-pa-md">
    <q-form @submit="onSubmit" class="q-gutter-md">

      <div class="row col-12">
        <q-checkbox clickable v-model="admin"  v-on:click.native="checkAll()" val="Admin" label="Admin" color="red"  />
      </div>

      <div class="row">
        <div class="q-pa-md" style="max-width: 350px"
        v-for="grp,index,val in data_teste" :key="index"
        >
          <q-list bordered >
            <q-item clickable v-ripple>
            <q-checkbox clickable v-on:click.native="checkGroup(index)" v-model="groups" :val="index" :label="index" :color="colors[val]" />
            </q-item>
            <q-separator />
            <q-item clickable v-ripple
            v-for="permission in grp" :key="permission"
            >
              <q-checkbox  keep-color v-model="permissions" :val="permission" :label="permission" :color="colors[val]" />
            </q-item>
          </q-list>
        </div>
      </div>
      <div>
        <q-btn label="Salvar" type="submit" color="primary"/>
      </div>
    </q-form>
  </div>
</template>

<script>
import { axiosInstance } from 'boot/axios'

export default {
  name: 'CardPermission',
  props: ['id'],
  data () {
    return {
      // cores da view
      teal: false,
      orange: false,
      red: false,
      cyan: false,
      // dados de teste
      data_teste: {
        administração: [
          'controle de usuarios',
          'controle de tickets',
          'controle de servers'
        ],

        suporte: [
          'controle de usuarios suporte',
          'controle de tickets suporte',
          'controle de servers suporte'
        ],
        desenvolvimento: [
          'auth31',
          'auth32'
        ]
      },

      data: [],
      admin: false,
      contador: 0,
      colors: ['teal', 'orange', 'red', 'cyan', 'blue'],
      groups: [],
      // permissions do usuario
      permissions: []
    }
  },
  methods: {
    getPermissions () {
      // var individualcheck
      Object.entries(this.data_teste).forEach((group, index) => {
        // this.groups[group[0]] = true
        // if (this.groups.indexOf(group[0]) === -1) this.groups.push(group[0])
        group[1].forEach(permission => {
          if (this.permissions.indexOf(permission) === -1) this.permissions.push(permission)
          // if (this.permissions.indexOf(permission) === -1) this.permissions.push(index)
        })
      })
      return this.data
    },
    onSubmit () {
      console.log(this.groups)
      console.log(this.permissions)
      console.log(this.admin)
      axiosInstance.post('/users/auths/' + this.id).then((response) => {
        console.log(response)
      })
    },
    conta () {
      this.contador++
      return (this.contador - 303)
    },
    checkGroup (index) {
      if (this.groups.find(group => group === index)) {
        this.data_teste[index].forEach(permission => {
          this.permissions.push(permission)
        })
      } else {
        this.data_teste[index].forEach(permission => {
          this.permissions = this.permissions.filter(e => e !== permission)
        })
      }
    },
    checkAll () {
      if (!this.admin) {
        this.permissions = []
        return 'false'
      }
      var allPermissions = this.data_teste
      Object.entries(allPermissions).forEach((permission) => {
        permission.forEach((permission_, index) => {
          if (index !== 0) {
            permission_.forEach((permission__) => {
              if (!this.permissions.find(permission => permission === permission__)) {
                this.permissions.push(permission__)
              }
            })
          }
        })
      })
    },
    checkGroupReverse () {
      const selecionPermissions = this.permissions
      const allPermissions = this.data_teste
      Object.entries(allPermissions).forEach((permission) => {
        const permissionsGroup = permission[1]
        const permissionName = permission[0]
        const pass = permissionsGroup.every(permissionGroup => {
          const exist = selecionPermissions.find(permission => permission === permissionGroup)
          if (exist === undefined) {
            return false
          } else {
            return true
          }
        })
        if (!pass) {
          this.groups = this.groups.filter(e => e !== permissionName)
        } else {
          if (!this.groups.find(group => group === permissionName)) {
            this.groups.push(permissionName)
          }
        }
      })
    }
  },
  beforeMount () {
    this.getPermissions()
  },
  watch: {
    permissions: function () {
      const selecionPermissions = this.permissions
      const allPermissions = this.data_teste
      var cont = 0

      Object.entries(allPermissions).forEach((permission) => {
        const permissionsGroup = permission[1]
        const permissionName = permission[0]
        const pass = permissionsGroup.every(permissionGroup => {
          cont++
          const exist = selecionPermissions.find(permission => permission === permissionGroup)
          if (exist === undefined) {
            return false
          } else {
            return true
          }
        })
        if (!pass) {
          this.groups = this.groups.filter(e => e !== permissionName)
        } else {
          if (!this.groups.find(group => group === permissionName)) {
            this.groups.push(permissionName)
          }
        }
      })
      if (cont === selecionPermissions.length) {
        this.admin = true
      } else {
        this.admin = false
      }
    }
  }
}
</script>
