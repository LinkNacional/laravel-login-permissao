<template>
  <q-layout view="lHh Lpr lFf" >
    <q-header style="background-color:#DAE300 ;color:#343B45" elevated>
      <q-toolbar>
        <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="leftDrawerOpen = !leftDrawerOpen"
        />

        <q-toolbar-title>
          sistema de chamados
        </q-toolbar-title>

        <div><a href='#' @click="logout">sair</a></div>
      </q-toolbar>
    </q-header>

    <q-drawer
      v-model="leftDrawerOpen"
      show-if-above
      bordered
      content-class="bg-grey-1"
    >
      <q-list>
        <q-item-label
          header
          class="text-grey-8"
        >
          menu
        </q-item-label>

        <EssentialLink
          v-for="link in essentialLinks"
          :key="link.title"
          v-bind="link"
        />
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import EssentialLink from 'components/EssentialLink.vue'
import { axiosInstance } from 'boot/axios'

const linksData = [
  {
    title: 'Dashboard',
    caption: '',
    icon: 'dashboard',
    link: 'dashboard'
  },
  {
    title: 'usuários',
    caption: 'Menu de usuários',
    icon: 'supervisor_account',
    link: 'users'
  }

]

export default {
  name: 'MainLayout',
  components: { EssentialLink },
  data () {
    return {
      leftDrawerOpen: false,
      essentialLinks: linksData
    }
  },
  methods: {
    logout () {
      axiosInstance.post('/logout')
        .catch((error) => {
          console.log(error)
        })
    }
  }
}
</script>
